function varargout = inver(x, y, z, alpha, beta, gamma, varargin)
%********************************************************************
% 函数名: inver (Inverse Kinematics)
% 描述: 6-PUS Stewart平台逆解
%       给定动平台位姿 (x,y,z,alpha,beta,gamma)，计算6个驱动副位移 q1~q6
%       旋转顺序: R = Rz(gamma) * Ry(beta) * Rx(alpha)  (ZYX欧拉角)
%
% 输入:
%       x, y, z         - 动平台参考点位置 [mm]
%       alpha, beta, gamma - 动平台姿态 (ZYX欧拉角, rad)
%       varargin{1}     - (可选) 几何参数结构体, 如不提供则使用 params()
%                         结构体字段: c, d, e, lamuda, miu
%
% 输出: (两种调用方式)
%       [q1,q2,q3,q4,q5,q6] = inver(...)  — 分别输出6个驱动量
%       q = inver(...)                     — 输出 6×1 向量
%
% 调用示例:
%       [q1,q2,q3,q4,q5,q6] = inver(0,0,132.612,0,0,0);
%       q = inver(5,-3,110,0.1,-0.05,0.08);
%       q = inver(0,0,132.612,0,0,0, myParams);  % 使用自定义参数
%********************************************************************

%% 解析几何参数
if nargin >= 7 && ~isempty(varargin{1})
    prm = varargin{1};
else
    prm = params();
end

c = prm.c;
d = prm.d;
e = prm.e;
lamuda = prm.lamuda;
miu = prm.miu;

%% 静平台铰点坐标 (在基座平面内，2D向量)
% 静平台铰点固定不动，只有z方向移动的滑块
a1 = [-c*sin(lamuda/2);  c*cos(lamuda/2)];
a2 = [-c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a3 = [-c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a4 = [ c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a5 = [ c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a6 = [ c*sin(lamuda/2);  c*cos(lamuda/2)];

%% 动平台铰点坐标 (在动平台局部坐标系中，z=0)
b1 = [-d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];
b2 = [-d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b3 = [-d*sin(miu/2);      -d*cos(miu/2);      0];
b4 = [ d*sin(miu/2);      -d*cos(miu/2);      0];
b5 = [ d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b6 = [ d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];

%% 旋转矩阵 R = Rz(gamma)*Ry(beta)*Rx(alpha)  ZYX欧拉角
Rx = [1,  0,           0;
      0,  cos(alpha), -sin(alpha);
      0,  sin(alpha),  cos(alpha)];

Ry = [cos(beta),  0, sin(beta);
      0,          1, 0;
     -sin(beta),  0, cos(beta)];

Rz = [cos(gamma), -sin(gamma), 0;
      sin(gamma),  cos(gamma), 0;
      0,           0,          1];

R = Rz * Ry * Rx;  % 总体旋转矩阵 (ZYX顺序)

%% 计算动平台铰点在全局坐标系中的位置: bb_i = P + R * b_i
P = [x; y; z];

BB = zeros(3, 6);
BB(:, 1) = P + R * b1;
BB(:, 2) = P + R * b2;
BB(:, 3) = P + R * b3;
BB(:, 4) = P + R * b4;
BB(:, 5) = P + R * b5;
BB(:, 6) = P + R * b6;

%% 计算各驱动副位移
% 约束方程: (bb_ix - a_ix)^2 + (bb_iy - a_iy)^2 + (bb_iz - q_i)^2 = e^2
% 解得: q_i = bb_iz - sqrt(e^2 - (bb_ix - a_ix)^2 - (bb_iy - a_iy)^2)

A_all = [a1, a2, a3, a4, a5, a6];  % 2x6 矩阵，静平台铰点x,y坐标

q = zeros(6, 1);
for i = 1:6
    dx = BB(1, i) - A_all(1, i);
    dy = BB(2, i) - A_all(2, i);
    radicand = e^2 - dx^2 - dy^2;

    radicand_tol = 1e-10 * e^2;
    if radicand < -radicand_tol
        warning('inver:unreachable', ...
            '第%d条支链连杆长度不足，无法到达指定位置；根号项=%.6g。', i, radicand);
        q(i) = NaN;
        continue;
    elseif radicand < 0
        radicand = 0;  % 仅消除浮点舍入造成的微小负值
    end

    q(i) = BB(3, i) - sqrt(radicand);
end

%% 输出
if nargout <= 1
    % 单输出: 返回向量
    varargout{1} = q;
else
    % 多输出: 分别返回 q1~q6
    varargout{1} = q(1);
    varargout{2} = q(2);
    varargout{3} = q(3);
    varargout{4} = q(4);
    varargout{5} = q(5);
    varargout{6} = q(6);
end

end
