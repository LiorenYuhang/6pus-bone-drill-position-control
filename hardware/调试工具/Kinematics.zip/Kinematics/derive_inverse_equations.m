%% derive_inverse_equations.m — 6-PUS Stewart平台逆解方程符号推导
%  输出两个版本的 q1~q6 显式方程:
%    版本A (带参数): q_i = f(x,y,z,α,β,γ, c,d,e,λ,μ)  保留所有几何参数符号
%    版本B (数值版): q_i = f(x,y,z,α,β,γ)              代入 params.m 中的 c,d,e,λ,μ
%  旋转顺序: R = Rz(gamma)*Ry(beta)*Rx(alpha)  (ZYX欧拉角)
clear; clc;
script_dir = fileparts(mfilename('fullpath'));

fprintf('╔══════════════════════════════════════════════════════════════╗\n');
fprintf('║   6-PUS Stewart Platform — Inverse Kinematics Derivation   ║\n');
fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');

%% ====== 第1步: 定义符号变量 ======
syms x y z alpha beta gamma real;       % 位姿 (6 DOF)
syms c d e lamuda miu real;             % 几何参数
assume(c > 0 & d > 0 & e > 0);

fprintf('Symbolic variables:\n');
fprintf('  Pose:    x, y, z, alpha, beta, gamma\n');
fprintf('  Geometry: c, d, e, lamuda, miu\n\n');

%% ====== 第2步: 旋转矩阵 R = Rz*Ry*Rx ======
Rx = [1,  0,           0;
      0,  cos(alpha), -sin(alpha);
      0,  sin(alpha),  cos(alpha)];

Ry = [cos(beta),  0, sin(beta);
      0,          1, 0;
     -sin(beta),  0, cos(beta)];

Rz = [cos(gamma), -sin(gamma), 0;
      sin(gamma),  cos(gamma), 0;
      0,           0,          1];

R = Rz * Ry * Rx;  % ZYX Euler rotation matrix

%% ====== 第3步: 铰点坐标 ======
% 静平台铰点 (基座平面2D)
a1 = [-c*sin(lamuda/2);  c*cos(lamuda/2)];
a2 = [-c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a3 = [-c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a4 = [ c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a5 = [ c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a6 = [ c*sin(lamuda/2);  c*cos(lamuda/2)];

% 动平台铰点 (局部坐标系3D)
b1 = [-d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];
b2 = [-d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b3 = [-d*sin(miu/2);      -d*cos(miu/2);      0];
b4 = [ d*sin(miu/2);      -d*cos(miu/2);      0];
b5 = [ d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b6 = [ d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];

%% ====== 第4步: 坐标变换 bb_i = P + R*b_i ======
P = [x; y; z];
a_all = {a1, a2, a3, a4, a5, a6};
b_all = {b1, b2, b3, b4, b5, b6};

bb = cell(1,6);
q_sym = cell(1,6);
for i = 1:6
    bb{i} = P + R * b_all{i};
    % 逆解: q_i = bb_iz - sqrt(e^2 - (bb_ix-a_ix)^2 - (bb_iy-a_iy)^2)
    q_sym{i} = bb{i}(3) - sqrt(e^2 - (bb{i}(1)-a_all{i}(1))^2 - (bb{i}(2)-a_all{i}(2))^2);
end

%% ====== 第5步: 几何参数数值 ======
prm = params();
c_val = prm.c;
d_val = prm.d;
e_val = prm.e;
lamuda_val = prm.lamuda;
miu_val = prm.miu;

q_num = cell(1,6);
for i = 1:6
    q_num{i} = subs(q_sym{i}, [c, d, e, lamuda, miu], ...
                             [c_val, d_val, e_val, lamuda_val, miu_val]);
end

%% ###############################################################
%%  ====== 版本A: 带全部几何参数的逆解方程 ======
%% ###############################################################
fprintf('╔══════════════════════════════════════════════════════════════╗\n');
fprintf('║  VERSION A: q_i = f(x,y,z,alpha,beta,gamma, c,d,e,lamuda,miu) ║\n');
fprintf('║  (保留所有几何参数符号)                                      ║\n');
fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');

fprintf('Kinematic constraint (leg i):\n');
fprintf('  (bb_ix - a_ix)^2 + (bb_iy - a_iy)^2 + (bb_iz - q_i)^2 = e^2\n');
fprintf('  => q_i = bb_iz - sqrt( e^2 - (bb_ix-a_ix)^2 - (bb_iy-a_iy)^2 )\n');
fprintf('  where bb_i = P + Rz(gamma)*Ry(beta)*Rx(alpha) * b_i\n\n');

for i = 1:6
    fprintf('────────────────────────────────────────────────────────────\n');
    fprintf('  LEG %d:\n', i);
    fprintf('    q%d = %s\n', i, char(q_sym{i}));
    fprintf('\n');
end

%% ###############################################################
%%  ====== 版本B: 代入几何参数数值后的逆解方程 ======
%% ###############################################################
fprintf('╔══════════════════════════════════════════════════════════════╗\n');
fprintf('║  VERSION B: q_i = f(x,y,z,alpha,beta,gamma)                 ║\n');
fprintf('║  (c=%.1f, d=%.1f, e=%.1f, lamuda=%.1f deg, miu=%.1f deg) ║\n', ...
    c_val, d_val, e_val, rad2deg(lamuda_val), rad2deg(miu_val));
fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');

for i = 1:6
    fprintf('────────────────────────────────────────────────────────────\n');
    fprintf('  LEG %d:\n', i);
    fprintf('    q%d = %s\n', i, char(vpa(q_num{i}, 8)));
    fprintf('\n');
end

%% ###############################################################
%%  ====== 导出为 MATLAB 函数文件 ======
%% ###############################################################
fprintf('╔══════════════════════════════════════════════════════════════╗\n');
fprintf('║  Exporting MATLAB function files ...                        ║\n');
fprintf('╚══════════════════════════════════════════════════════════════╝\n\n');

% --- 版本A: 带全部参数 ---
q_vec = [q_sym{1}; q_sym{2}; q_sym{3}; q_sym{4}; q_sym{5}; q_sym{6}];
matlabFunction(q_vec, 'File', fullfile(script_dir, 'inverse_equations_param'), ...
    'Vars', {x, y, z, alpha, beta, gamma, c, d, e, lamuda, miu}, ...
    'Outputs', {'q'});
fprintf('  [OK] inverse_equations_param.m\n');
fprintf('       q = inverse_equations_param(x,y,z,alpha,beta,gamma, c,d,e,lamuda,miu)\n');
fprintf('       Returns 6x1 vector [q1;q2;q3;q4;q5;q6]\n\n');

% --- 版本B: 代入数值 ---
q_vec_num = [q_num{1}; q_num{2}; q_num{3}; q_num{4}; q_num{5}; q_num{6}];
matlabFunction(q_vec_num, 'File', fullfile(script_dir, 'inverse_equations_numeric'), ...
    'Vars', {x, y, z, alpha, beta, gamma}, ...
    'Outputs', {'q'});
fprintf('  [OK] inverse_equations_numeric.m\n');
fprintf('       q = inverse_equations_numeric(x,y,z,alpha,beta,gamma)\n');
fprintf('       Returns 6x1 vector [q1;q2;q3;q4;q5;q6]\n\n');

%% ###############################################################
%%  ====== 验证 ======
%% ###############################################################
fprintf('────────────────────────────────────────────────────────────\n');
fprintf('  Verification: comparing exported functions against inver.m\n');
fprintf('────────────────────────────────────────────────────────────\n\n');

prm = params();
zN = prm.z_nom;  % 由 params.m 派生

test_poses = [
    0,    0,    zN,       0,     0,     0;     % z_nom = mid-stroke
    5,   -3,    zN - 5,   0.1,  -0.05,  0.08;
   10,    8,    zN - 15,  0,     0,     0;
    0,    0,    zN,       0.15,  0.1,  -0.12;  % z_nom = mid-stroke
    8,   -5,    zN - 10,  0.2,  -0.15,  0.25;
];

all_pass = true;
for k = 1:size(test_poses, 1)
    xp = test_poses(k,1); yp = test_poses(k,2); zp = test_poses(k,3);
    ap = test_poses(k,4); bp = test_poses(k,5); gp = test_poses(k,6);

    % inver reference
    [q1_i, q2_i, q3_i, q4_i, q5_i, q6_i] = inver(xp, yp, zp, ap, bp, gp);
    q_ref = [q1_i, q2_i, q3_i, q4_i, q5_i, q6_i];

    % Version A (with params)
    qA = inverse_equations_param(xp,yp,zp,ap,bp,gp, c_val,d_val,e_val,lamuda_val,miu_val);
    qA = qA(:)';
    errA = norm(q_ref - qA);

    % Version B (numeric)
    qB = inverse_equations_numeric(xp,yp,zp,ap,bp,gp);
    qB = qB(:)';
    errB = norm(q_ref - qB);

    okA = errA < 1e-10;
    okB = errB < 1e-10;
    if ~okA || ~okB, all_pass = false; end
    fprintf('  Test %d:  err_param=%.1e %s   err_numeric=%.1e %s\n', ...
        k, errA, tf(okA), errB, tf(okB));
end

fprintf('\n  Overall: %s\n', tf(all_pass));
fprintf('\nDerivation complete.\n');

%% helper
function s = tf(cond)
    if cond, s = 'OK'; else, s = 'FAIL'; end
end
