%% diff_q6.m — 6-PUS Stewart平台运动学约束方程及Jacobian符号推导
%  本文件用于符号推导运动学约束方程对位姿的偏导数(Jacobian矩阵)
%  旋转顺序: R = Rz(gamma)*Ry(beta)*Rx(alpha)  (ZYX欧拉角)
%  注意: 此文件仅作符号推导/验证用途，实际数值计算由 forward_kinematics.m 完成
clear; clc;

%% 符号变量定义
syms x y z alpha beta gamma real;       % 位姿变量
syms q1 q2 q3 q4 q5 q6 real;            % 驱动副位移
syms c d e lamuda miu real;             % 几何参数 (正实数)

%% 旋转矩阵 (ZYX欧拉角: R = Rz*Ry*Rx)
Rx = [1,  0,           0;
      0,  cos(alpha), -sin(alpha);
      0,  sin(alpha),  cos(alpha)];

Ry = [cos(beta),  0, sin(beta);
      0,          1, 0;
     -sin(beta),  0, cos(beta)];

Rz = [cos(gamma), -sin(gamma), 0;
      sin(gamma),  cos(gamma), 0;
      0,           0,          1];

R = Rz * Ry * Rx;  % 总体旋转矩阵

P = [x; y; z];

%% 静平台(基座)铰点坐标 — 在基座平面内的2D向量
% 基座铰点沿竖直导轨滑动，固定(x,y)位置
a1 = [-c*sin(lamuda/2);  c*cos(lamuda/2)];
a2 = [-c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a3 = [-c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a4 = [ c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a5 = [ c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a6 = [ c*sin(lamuda/2);  c*cos(lamuda/2)];

%% 动平台铰点坐标 — 在动平台局部坐标系中的3D向量(z=0)
b1 = [-d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];
b2 = [-d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b3 = [-d*sin(miu/2);      -d*cos(miu/2);      0];
b4 = [ d*sin(miu/2);      -d*cos(miu/2);      0];
b5 = [ d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b6 = [ d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];

%% 动平台铰点在全局坐标系中的坐标变换: bb_i = P + R * b_i
bb1 = P + R * b1;
bb2 = P + R * b2;
bb3 = P + R * b3;
bb4 = P + R * b4;
bb5 = P + R * b5;
bb6 = P + R * b6;

%% 运动学约束方程
% 每根连杆: (bb_ix - a_ix)^2 + (bb_iy - a_iy)^2 + (bb_iz - q_i)^2 = e^2
% 整理为: E_i = bb_iz - sqrt(e^2 - (bb_ix-a_ix)^2 - (bb_iy-a_iy)^2) - q_i = 0
E1 = bb1(3) - sqrt(e^2 - (bb1(1)-a1(1))^2 - (bb1(2)-a1(2))^2) - q1;
E2 = bb2(3) - sqrt(e^2 - (bb2(1)-a2(1))^2 - (bb2(2)-a2(2))^2) - q2;
E3 = bb3(3) - sqrt(e^2 - (bb3(1)-a3(1))^2 - (bb3(2)-a3(2))^2) - q3;
E4 = bb4(3) - sqrt(e^2 - (bb4(1)-a4(1))^2 - (bb4(2)-a4(2))^2) - q4;
E5 = bb5(3) - sqrt(e^2 - (bb5(1)-a5(1))^2 - (bb5(2)-a5(2))^2) - q5;
E6 = bb6(3) - sqrt(e^2 - (bb6(1)-a6(1))^2 - (bb6(2)-a6(2))^2) - q6;

E_vec = [E1; E2; E3; E4; E5; E6];
pose_vars = [x, y, z, alpha, beta, gamma];

%% 正解Jacobian: J_forward = ∂E/∂(pose)  (6×6矩阵)
fprintf('=== 正解Jacobian (∂E/∂pose) ===\n');
J_forward = jacobian(E_vec, pose_vars);
% pretty(J_forward);  % 如需查看展开表达式，取消此行注释

%% 逆解Jacobian: J_inverse = ∂E/∂q  (6×6矩阵, 实际等于 -I)
fprintf('\n=== 逆解Jacobian (∂E/∂q) ===\n');
q_vars = [q1, q2, q3, q4, q5, q6];
J_inverse = jacobian(E_vec, q_vars);
% 注意: ∂E/∂q = -I (6×6单位矩阵取负), 因为E_i = ... - q_i

%% 导出符号Jacobian为MATLAB函数 (用于快速数值计算, 可选)
fprintf('\n=== 生成数值Jacobian函数 ===\n');
fprintf('如需导出为MATLAB函数文件，运行以下命令:\n');
fprintf('  matlabFunction(J_forward, ''File'', ''jacobian_forward_func'', ''Vars'', {[x;y;z;alpha;beta;gamma], c, d, e, lamuda, miu});\n');

fprintf('\n符号推导完成。在forward_kinematics.m中使用数值差分代替了此符号Jacobian。\n');
