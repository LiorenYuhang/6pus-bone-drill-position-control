function p = joint_constraint_params()
%JOINT_CONSTRAINT_PARAMS 6-PUS的P/U/S副专用约束参数。
% 本函数在params()的机构参数基础上增加关节约束，不修改params.m。

p = params();

%% P副：绝对驱动坐标25~75 mm，等价相对行程0~50 mm
p.joint.P.q_min = p.q_min;
p.joint.P.q_max = p.q_max;
p.joint.P.q_mid = p.q_mid;
p.joint.P.stroke = p.stroke;
p.joint.P.relative_min = 0;
p.joint.P.relative_max = p.stroke;

%% U副：MISUMI E-UNCA6-P/UNCA6单节万向接头
% 厂家定义的“动作角”是输入轴与输出轴两轴线的总夹角，容许值30°。
% 六个P副轴均沿基坐标系+Z方向；控制计算向内保留3°安全裕量。
p.joint.U.shaft_base = repmat([0;0;1],1,6);
p.joint.U.max_geom_deg = 30;
p.joint.U.safety_margin_deg = 3;
p.joint.U.max_safe_deg = ...
    p.joint.U.max_geom_deg-p.joint.U.safety_margin_deg;
p.joint.U.model = 'vendor_total_operating_angle';
p.joint.U.source = 'MISUMI E-UNCA/UNCA allowable operating angle';

%% S副：厂家给出的最大摆角30°，控制安全值向内留3°
p.joint.S.max_geom_deg = 30;
p.joint.S.safety_margin_deg = 3;
p.joint.S.max_safe_deg = ...
    p.joint.S.max_geom_deg-p.joint.S.safety_margin_deg;
p.joint.S.axis_platform = repmat([0;0;1],1,6);
end
