function [x, y, z, alpha, beta, gamma] = forward_kinematics(q1, q2, q3, q4, q5, q6, varargin)
%********************************************************************
% 函数名: forward_kinematics (Forward Kinematics)
% 描述: 6-PUS Stewart平台正解 (Newton-Raphson数值迭代法)
%       给定6个驱动副位移 q1~q6，求解动平台位姿 (x,y,z,alpha,beta,gamma)
%
% 输入:
%       q1~q6     - 6个P副(竖直滑块)的位移量 [mm]
%       varargin  - 可选参数 (名称-值对):
%           'init_pose', [x0,y0,z0,a0,b0,g0] - 迭代初始位姿
%                       默认使用 params().z_nom 作为标称高度
%           'tol', tol       - 收敛容差 (默认 1e-7)
%           'max_iter', N    - 最大迭代次数 (默认 100)
%           'params', prm    - 几何参数结构体 (默认 params())
%
% 输出:
%       x, y, z         - 动平台参考点位置 [mm]
%       alpha, beta, gamma - 动平台姿态 (ZYX欧拉角, rad)
%********************************************************************

%% 获取几何参数
prm = params();  % 默认参数
% 检查是否通过名称-值对传入了自定义参数
for k = 1:2:length(varargin)-1
    if strcmp(varargin{k}, 'params')
        prm = varargin{k+1};
        break;
    end
end

%% 解析可选输入参数
p = inputParser;
addParameter(p, 'init_pose', [0, 0, prm.z_nom, 0, 0, 0]);
addParameter(p, 'tol', 1e-7);
addParameter(p, 'max_iter', 100);
addParameter(p, 'params', prm);
parse(p, varargin{:});

init_pose = p.Results.init_pose;
tol = p.Results.tol;
max_iter = p.Results.max_iter;
prm = p.Results.params;

%% 几何参数 (从参数结构体获取)
c = prm.c;
d = prm.d;
e = prm.e;
lamuda = prm.lamuda;
miu = prm.miu;

%% 静平台铰点坐标 (2D, 在基座平面内)
a1 = [-c*sin(lamuda/2);  c*cos(lamuda/2)];
a2 = [-c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a3 = [-c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a4 = [ c*cos(pi/6+lamuda/2); -c*sin(pi/6+lamuda/2)];
a5 = [ c*cos(pi/6-lamuda/2); -c*sin(pi/6-lamuda/2)];
a6 = [ c*sin(lamuda/2);  c*cos(lamuda/2)];
A_all = [a1, a2, a3, a4, a5, a6];  % 2x6

%% 动平台铰点坐标 (在动平台局部坐标系中)
b1 = [-d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];
b2 = [-d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b3 = [-d*sin(miu/2);      -d*cos(miu/2);      0];
b4 = [ d*sin(miu/2);      -d*cos(miu/2);      0];
b5 = [ d*cos(pi/6-miu/2);  d*sin(pi/6-miu/2); 0];
b6 = [ d*cos(pi/6+miu/2);  d*sin(pi/6+miu/2); 0];
B_all = [b1, b2, b3, b4, b5, b6];  % 3x6

%% 目标驱动值
q_target = [q1; q2; q3; q4; q5; q6];

%% 初始化位姿
pose = init_pose(:);  % 6x1 向量 [x; y; z; alpha; beta; gamma]

%% Newton-Raphson 迭代
converged = false;
for iter = 1:max_iter
    x   = pose(1);
    y   = pose(2);
    z   = pose(3);
    alpha = pose(4);
    beta  = pose(5);
    gamma = pose(6);

    % 计算当前位姿对应的误差向量
    F = compute_error(x, y, z, alpha, beta, gamma, ...
                      A_all, B_all, e, q_target);

    % 检查收敛
    if max(abs(F)) < tol
        converged = true;
        break;
    end

    % 数值计算 Jacobian 矩阵 (6x6), 使用前向差分
    J = compute_jacobian(x, y, z, alpha, beta, gamma, ...
                         A_all, B_all, e, q_target, tol);

    % Newton-Raphson 步进
    delta = -J \ F;  % 解线性方程组 J * delta = -F

    % 更新位姿
    pose = pose + delta;

    % 限制角度范围 (避免数值漂移)
    pose(4) = atan2(sin(pose(4)), cos(pose(4)));
    pose(5) = atan2(sin(pose(5)), cos(pose(5)));
    pose(6) = atan2(sin(pose(6)), cos(pose(6)));
end

if ~converged
    warning('forward_kinematics: 迭代未收敛 (迭代%d次后 ||F|| = %.2e)', ...
            max_iter, max(abs(F)));
end

%% 输出结果
x = pose(1);
y = pose(2);
z = pose(3);
alpha = pose(4);
beta  = pose(5);
gamma = pose(6);

end

%% ==================== 内部函数 ====================

function F = compute_error(x, y, z, alpha, beta, gamma, A_all, B_all, e, q_target)
% 计算6个运动学约束方程的误差值
% F_i = bb_iz - sqrt(e^2 - (bb_ix - a_ix)^2 - (bb_iy - a_iy)^2) - q_i

% 旋转矩阵 R = Rz*Ry*Rx
R = rotation_matrix(alpha, beta, gamma);
P = [x; y; z];

F = zeros(6, 1);
for i = 1:6
    % 动平台铰点在全局坐标中的位置
    bb = P + R * B_all(:, i);

    % 水平距离平方
    dx = bb(1) - A_all(1, i);
    dy = bb(2) - A_all(2, i);
    horz_sq = dx*dx + dy*dy;

    % 计算 sqrt 内部值
    radicand = e*e - horz_sq;

    if radicand < 0
        % 物理不可达：连杆长度不够，但仍返回连续误差以引导迭代
        F(i) = bb(3) - q_target(i);  % 忽略sqrt项，返回简化误差
    else
        F(i) = bb(3) - sqrt(radicand) - q_target(i);
    end
end
end

function J = compute_jacobian(x, y, z, alpha, beta, gamma, ...
                              A_all, B_all, e, q_target, tol)
% 使用前向差分计算数值Jacobian矩阵
% J(i,j) = dF_i / d(pose_j)

h_lin = max(1e-7, tol * 0.01);  % 位置步长
h_ang = max(1e-8, tol * 0.001); % 角度步长

pose0 = [x; y; z; alpha; beta; gamma];
F0 = compute_error(x, y, z, alpha, beta, gamma, ...
                   A_all, B_all, e, q_target);

J = zeros(6, 6);
for j = 1:6
    pose_pert = pose0;
    if j <= 3
        pose_pert(j) = pose_pert(j) + h_lin;
        h_used = h_lin;
    else
        pose_pert(j) = pose_pert(j) + h_ang;
        h_used = h_ang;
    end

    F_pert = compute_error(pose_pert(1), pose_pert(2), pose_pert(3), ...
                           pose_pert(4), pose_pert(5), pose_pert(6), ...
                           A_all, B_all, e, q_target);

    J(:, j) = (F_pert - F0) / h_used;
end
end

function R = rotation_matrix(alpha, beta, gamma)
% 计算 ZYX 欧拉角旋转矩阵: R = Rz(gamma) * Ry(beta) * Rx(alpha)

ca = cos(alpha); sa = sin(alpha);
cb = cos(beta);  sb = sin(beta);
cg = cos(gamma); sg = sin(gamma);

R = [cg*cb,  cg*sb*sa - sg*ca,  cg*sb*ca + sg*sa;
     sg*cb,  sg*sb*sa + cg*ca,  sg*sb*ca - cg*sa;
     -sb,     cb*sa,             cb*ca];
end
