%% test.m — 6-PUS Stewart平台运动学正逆解验证测试
%  测试流程: 给定位姿 → 逆解求q → 正解恢复位姿 → 比较误差
%  旋转顺序: R = Rz(gamma)*Ry(beta)*Rx(alpha) (ZYX欧拉角)
%  使用 params() 配置机构参数, 便于后续修改
clear; clc;

fprintf('========== 6-PUS Stewart平台 正逆运动学验证 ==========\n\n');

%% 加载机构参数
prm = params();

fprintf('几何参数:\n');
fprintf('  c = %.2f mm (静平台半径)\n', prm.c);
fprintf('  d = %.2f mm (动平台半径)\n', prm.d);
fprintf('  e = %.2f mm (连杆长度, U→S)\n', prm.e);
fprintf('  λ = %.1f°, μ = %.1f°\n', rad2deg(prm.lamuda), rad2deg(prm.miu));
fprintf('\n水平距离 h = sqrt(c²+d²-2cd cos(π/3-(λ+μ)/2)) = %.4f mm\n', prm.h_zero);
fprintf('垂直投影 sqrt(e²-h²) = %.4f mm\n', prm.sqrt_term);
fprintf('\n滑块行程: q ∈ [%.2f, %.2f] mm, 中位 = %.2f mm\n', ...
    prm.q_min, prm.q_max, prm.q_mid);
fprintf('平台高度: z ∈ [%.2f, %.2f] mm, 标称 = %.2f mm\n\n', ...
    prm.z_min, prm.z_max, prm.z_nom);

%% ====== 测试1: 标称位姿 (中位行程) ======
fprintf('--- 测试1: 标称位姿 (中位行程) ---\n');
pose_in = [0, 0, prm.z_nom, 0, 0, 0];
test_round_trip(pose_in, prm);

%% ====== 测试2: 带平移和旋转的位姿 ======
fprintf('--- 测试2: 平移+旋转位姿 ---\n');
pose_in = [5, -3, prm.z_nom - 5, 0.1, -0.05, 0.08];
test_round_trip(pose_in, prm);

%% ====== 测试3: 纯平移 ======
fprintf('--- 测试3: 纯平移 ---\n');
pose_in = [10, 8, prm.z_nom - 15, 0, 0, 0];
test_round_trip(pose_in, prm);

%% ====== 测试4: 纯旋转 (中位行程) ======
fprintf('--- 测试4: 纯旋转 (中位行程) ---\n');
pose_in = [0, 0, prm.z_nom, 0.15, 0.1, -0.12];
test_round_trip(pose_in, prm);

%% ====== 测试5: 大范围运动 ======
fprintf('--- 测试5: 大范围运动 ---\n');
pose_in = [8, -5, prm.z_nom - 10, 0.2, -0.15, 0.25];
test_round_trip(pose_in, prm);

%% ====== 测试6: 行程上下限 ======
fprintf('--- 测试6: 行程边界验证 ---\n');
fprintf('  下限 q=%.2f → z=%.2f:\n', prm.q_min, prm.z_min);
pose_min = [0, 0, prm.z_min, 0, 0, 0];
test_round_trip(pose_min, prm);

fprintf('  上限 q=%.2f → z=%.2f:\n', prm.q_max, prm.z_max);
pose_max = [0, 0, prm.z_max, 0, 0, 0];
test_round_trip(pose_max, prm);

fprintf('========== 测试完成 ==========\n');

%% ==================== 局部测试函数 ====================
function test_round_trip(pose_in, prm)
% 测试: 位姿 → 逆解 → 正解 → 恢复位姿，比较精度

x_in  = pose_in(1); y_in  = pose_in(2); z_in  = pose_in(3);
a_in  = pose_in(4); b_in  = pose_in(5); g_in  = pose_in(6);

fprintf('  输入位姿:  x=%.4f, y=%.4f, z=%.4f, α=%.4f, β=%.4f, γ=%.4f\n', ...
        x_in, y_in, z_in, a_in, b_in, g_in);

% Step 1: 逆解 (位姿 → 驱动量)
q = inver(x_in, y_in, z_in, a_in, b_in, g_in, prm);
assert(all(isfinite(q)), '逆解返回非有限值，输入位姿不可达。');
fprintf('  逆解 q:    [%.4f, %.4f, %.4f, %.4f, %.4f, %.4f]\n', q);

% 检查 q 是否在行程范围内
q_in_range = all(q >= prm.q_min - 1e-6 & q <= prm.q_max + 1e-6);
if ~q_in_range
    fprintf('  ⚠ 警告: q 超出行程范围 [%.2f, %.2f]!\n', prm.q_min, prm.q_max);
end

% Step 2: 正解 (驱动量 → 位姿), 使用标称位姿作为初始猜测
init_guess = [0, 0, prm.z_nom, 0, 0, 0];
[x_out, y_out, z_out, a_out, b_out, g_out] = ...
    forward_kinematics(q(1), q(2), q(3), q(4), q(5), q(6), ...
                       'init_pose', init_guess, 'tol', 1e-10, 'max_iter', 200, ...
                       'params', prm);
fprintf('  恢复位姿:  x=%.4f, y=%.4f, z=%.4f, α=%.4f, β=%.4f, γ=%.4f\n', ...
        x_out, y_out, z_out, a_out, b_out, g_out);

% Step 3: 误差分析
pos_err = norm([x_out-x_in; y_out-y_in; z_out-z_in]);
ang_err = norm([angDiff(a_out, a_in); angDiff(b_out, b_in); angDiff(g_out, g_in)]);

fprintf('  位置误差: %.2e mm,  姿态误差: %.2e rad\n', pos_err, ang_err);

% Step 4: 验证正解结果 (用恢复的位姿再做一次逆解，驱动量应一致)
q_verify = inver(x_out, y_out, z_out, a_out, b_out, g_out, prm);
q_err = norm(q - q_verify);
fprintf('  驱动量验证误差: %.2e\n', q_err);

assert(pos_err < 1e-6 && ang_err < 1e-6 && q_err < 1e-6, ...
    '正逆解往返误差超限：pos=%.3e, ang=%.3e, q=%.3e。', pos_err, ang_err, q_err);
fprintf('  结果: ✓ 通过\n\n');
end

function d = angDiff(a, b)
% 计算角度差 (考虑环绕)
d = atan2(sin(a-b), cos(a-b));
end
