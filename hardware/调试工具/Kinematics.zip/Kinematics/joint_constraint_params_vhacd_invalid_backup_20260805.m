function p = joint_constraint_params()
%JOINT_CONSTRAINT_PARAMS 6-PUS的P/U/S副专用约束参数。
% 本函数在params()的机构参数基础上增加关节约束，不修改params.m。

p = params();

%% P副：绝对驱动坐标25~75 mm，等价相对行程0~50 mm
p.joint.P.q_min = p.q_min;
p.joint.P.q_max = p.q_max;
p.joint.P.q_mid = p.q_mid;
p.joint.P.stroke = p.stroke;
p.joint.P.relative_min = 0;
p.joint.P.relative_max = p.stroke;

%% U副：从V2.0-2/ste.SLDASM提取的六组固定轴方向
% 列i对应支链Ai->Bi。坐标系与inver.m一致。
p.joint.U.axis1 = [ ...
   -1.0,  0.5,  0.5, -0.5, -0.5,  1.0;
    0.0, -sqrt(3)/2, -sqrt(3)/2, -sqrt(3)/2, -sqrt(3)/2, 0.0;
    0.0,  0.0,  0.0,  0.0,  0.0,  0.0];
p.joint.U.shaft0 = repmat([0;0;1],1,6);
p.joint.U.axis2 = cross(p.joint.U.shaft0,p.joint.U.axis1,1);
p.joint.U.R0 = zeros(3,3,6);
for i = 1:6
    p.joint.U.R0(:,:,i) = [p.joint.U.axis1(:,i), ...
                           p.joint.U.axis2(:,i), ...
                           p.joint.U.shaft0(:,i)];
end
% SolidWorks圆柱面轴向的正负没有物理唯一性。以下符号将六套同构
% 虎克铰统一映射到支链1所使用的扫描角度坐标。
p.joint.U.alpha_sign = [1,1,1,-1,-1,-1];
p.joint.U.beta_sign = [1,-1,1,1,-1,1];

data_file = fullfile(p.output_root,'关节约束计算', ...
    'u_joint_constraint_data.mat');
if ~isfile(data_file)
    error('joint_constraint_params:MissingData', ...
        '缺少虎克铰约束数据文件：%s',data_file);
end
u_data = load(data_file);
p.joint.U.data_file = data_file;
p.joint.U.direction_deg = u_data.direction_deg(:);
p.joint.U.radius_geom_deg = u_data.radius_geom_deg(:);
p.joint.U.radius_safe_deg = u_data.radius_safe_deg(:);
p.joint.U.safety_margin_deg = u_data.u_safety_margin_deg;
p.joint.U.angle_cap_deg = 90;

%% S副：厂家给出的最大摆角30°，控制安全值向内留3°
p.joint.S.max_geom_deg = 30;
p.joint.S.safety_margin_deg = 3;
p.joint.S.max_safe_deg = ...
    p.joint.S.max_geom_deg-p.joint.S.safety_margin_deg;
p.joint.S.axis_platform = repmat([0;0;1],1,6);
end
