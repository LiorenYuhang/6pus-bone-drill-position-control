function [valid,detail] = check_joint_constraints( ...
    x,y,z,alpha,beta,gamma,varargin)
%CHECK_JOINT_CONSTRAINTS 检查6-PUS位姿的P副、U副和S副约束。
% 姿态约定与inver.m完全一致：R=Rz(gamma)*Ry(beta)*Rx(alpha)。

if nargin >= 7 && ~isempty(varargin{1})
    prm = varargin{1};
else
    prm = joint_constraint_params();
end

[A,B_local] = joint_points(prm);
R = rotation_matrix_zyx(alpha,beta,gamma);
P = [x;y;z];
B_world = P+R*B_local;
q = inver(x,y,z,alpha,beta,gamma,prm);

detail.q = q;
detail.p_valid = isfinite(q) & ...
    q >= prm.joint.P.q_min-1e-10 & ...
    q <= prm.joint.P.q_max+1e-10;
detail.u_alpha_deg = nan(6,1);
detail.u_beta_deg = nan(6,1);
detail.u_radius_deg = nan(6,1);
detail.u_limit_deg = nan(6,1);
detail.u_valid = false(6,1);
detail.s_angle_deg = nan(6,1);
detail.s_valid = false(6,1);

platform_normal = R*[0;0;1];
for i = 1:6
    if ~isfinite(q(i))
        continue;
    end
    U = [A(:,i);q(i)];
    link = B_world(:,i)-U;
    link_dir = link/norm(link);

    % 以下符号与SolidWorks双轴扫描坐标一致。
    v = prm.joint.U.R0(:,:,i).'*link_dir;
    v = max(-1,min(1,v));
    alpha_u = prm.joint.U.alpha_sign(i)*atan2(v(2),v(3));
    beta_u = prm.joint.U.beta_sign(i)*(-asin(v(1)));
    alpha_u_deg = rad2deg(alpha_u);
    beta_u_deg = rad2deg(beta_u);
    radius_deg = hypot(alpha_u_deg,beta_u_deg);
    direction_deg = mod(atan2d(beta_u_deg,alpha_u_deg),360);
    radius_limit_deg = periodic_limit(direction_deg,prm.joint.U);

    detail.u_alpha_deg(i) = alpha_u_deg;
    detail.u_beta_deg(i) = beta_u_deg;
    detail.u_radius_deg(i) = radius_deg;
    detail.u_limit_deg(i) = radius_limit_deg;
    detail.u_valid(i) = radius_deg <= radius_limit_deg+1e-10;

    cos_s = max(-1,min(1,dot(platform_normal,link_dir)));
    detail.s_angle_deg(i) = acosd(cos_s);
    detail.s_valid(i) = ...
        detail.s_angle_deg(i) <= prm.joint.S.max_safe_deg+1e-10;
end

detail.all_p_valid = all(detail.p_valid);
detail.all_u_valid = all(detail.u_valid);
detail.all_s_valid = all(detail.s_valid);
valid = detail.all_p_valid && detail.all_u_valid && detail.all_s_valid;
end

function limit_deg = periodic_limit(direction_deg,u)
direction_grid = [u.direction_deg;360];
radius_grid = [u.radius_safe_deg;u.radius_safe_deg(1)];
limit_deg = interp1(direction_grid,radius_grid,direction_deg,'linear');
end

function [A,B] = joint_points(p)
c=p.c;d=p.d;lamuda=p.lamuda;miu=p.miu;
A=[-c*sin(lamuda/2),-c*cos(pi/6-lamuda/2), ...
   -c*cos(pi/6+lamuda/2), c*cos(pi/6+lamuda/2), ...
    c*cos(pi/6-lamuda/2), c*sin(lamuda/2); ...
    c*cos(lamuda/2),-c*sin(pi/6-lamuda/2), ...
   -c*sin(pi/6+lamuda/2),-c*sin(pi/6+lamuda/2), ...
   -c*sin(pi/6-lamuda/2), c*cos(lamuda/2)];
B=[-d*cos(pi/6+miu/2),-d*cos(pi/6-miu/2),-d*sin(miu/2), ...
    d*sin(miu/2),d*cos(pi/6-miu/2),d*cos(pi/6+miu/2); ...
    d*sin(pi/6+miu/2),d*sin(pi/6-miu/2),-d*cos(miu/2), ...
   -d*cos(miu/2),d*sin(pi/6-miu/2),d*sin(pi/6+miu/2); ...
    zeros(1,6)];
end

function R = rotation_matrix_zyx(alpha,beta,gamma)
ca=cos(alpha);sa=sin(alpha);cb=cos(beta);sb=sin(beta);
cg=cos(gamma);sg=sin(gamma);
R=[cg*cb,cg*sb*sa-sg*ca,cg*sb*ca+sg*sa; ...
   sg*cb,sg*sb*sa+cg*ca,sg*sb*ca-cg*sa; ...
   -sb,cb*sa,cb*ca];
end
