function test_joint_constraints()
%TEST_JOINT_CONSTRAINTS P/U/S关节约束的基本回归测试。
p = joint_constraint_params();

[ok0,d0] = check_joint_constraints(0,0,p.z_mid,0,0,0,p);
assert(ok0,'标称中位姿应满足全部安全约束。');
assert(all(abs(d0.q-p.q_mid)<1e-8),'标称位姿的q应全部为50 mm。');
assert(all(d0.p_valid) && all(d0.u_valid) && all(d0.s_valid));
assert(max(d0.u_angle_deg)-min(d0.u_angle_deg)<1e-8, ...
    '六套U副的名义动作角应一致。');

[ok_p,d_p] = check_joint_constraints(0,0,p.z_min-1,0,0,0,p);
assert(~ok_p && any(~d_p.p_valid),'q=24 mm应违反P副下限。');

% 两个固定回归位姿分别只触发U副和S副，防止两类角度被混用。
[ok_u,d_u] = check_joint_constraints(-14.6896831,14.8291447,134.601146, ...
    -0.279480618,-0.118352171,0.190504465,p);
assert(~ok_u && d_u.all_p_valid && ~d_u.all_u_valid && d_u.all_s_valid, ...
    'U副越界测试应只触发U副约束。');
[ok_s,d_s] = check_joint_constraints(-12.0739919,7.8374915,127.551027, ...
    -0.315789676,-0.147090622,-0.218340917,p);
assert(~ok_s && d_s.all_p_valid && d_s.all_u_valid && ~d_s.all_s_valid, ...
    'S副越界测试应只触发S副约束。');

assert(abs(p.joint.P.relative_min-0)<eps);
assert(abs(p.joint.P.relative_max-50)<eps);
assert(p.joint.U.max_geom_deg==30 && p.joint.U.max_safe_deg==27);
assert(p.joint.S.max_geom_deg==30 && p.joint.S.max_safe_deg==27);

fprintf('NOMINAL|valid=%d|q=[%s]\n',ok0,sprintf(' %.3f',d0.q));
fprintf('NOMINAL_U|max_angle=%.3f deg\n',max(d0.u_angle_deg));
fprintf('NOMINAL_S|max_angle=%.3f deg\n',max(d0.s_angle_deg));
fprintf('P_LOWER_TEST|valid=%d|min_q=%.3f mm\n',ok_p,min(d_p.q));
fprintf('U_LIMIT_TEST|valid=%d|max_U=%.3f|max_S=%.3f deg\n', ...
    ok_u,max(d_u.u_angle_deg),max(d_u.s_angle_deg));
fprintf('S_LIMIT_TEST|valid=%d|max_U=%.3f|max_S=%.3f deg\n', ...
    ok_s,max(d_s.u_angle_deg),max(d_s.s_angle_deg));
fprintf('JOINT_CONSTRAINT_TEST=PASS\n');
end
